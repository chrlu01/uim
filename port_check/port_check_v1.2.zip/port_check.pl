#
# Use file: port_check_(computername).txt to define all servers, type and port to check
# or use -hi to define your serverlist ("server1:port|server2:port"
#
# format: server:port 
#    where:
#       server: server or url
#       port: 80 or http(80)
#       if first character is a #, it's a comment
#
# Order of input files:
# - if "-hi" is usd this is the only server input selected
# - if file port_check.txt exist, it will be taken (only if previous is not true)
# - if port_check_servername.txt exist it will be taken (only if previous is not true)
#       
#      
# Updates: Version 1.3
# 20/06/17: ignore empty lines   
# 21/06/17: add option printopen (so that you only receive a print in case a port is closed)
# 22/06/17: if input file: port_check.txt is available use it instead of file with servername in it
#           add switch to perform also a ping for servers that have a port closed
# 28/06/17: add switch to print counters
# 30/06/17: add input switches:
#      -hi"server:port|server:port"
#      -po"y/n" print also a line for ports that are open
#      -cp"y/n" ping also servers where port is closed
#      -pc"y/n" add counters in print statements  
#      -pt"y/n" add totals as last line
#      -di: (opt) input directory
#      -fi: (opt) input file" 
# 04/07/17: if port is not open add ip addess if found, else set unknown
# 13/10/17: added -pr (protocol), can be: tcp or udp, default: tcp
# 06/11/19: test missing if user defined input file was used in -fi
#

use IO::Socket;
use Net::Ping;
use Socket;

# --- get parameters
&getparams();

# --- variables
$count_ok=0;
$count_nok=0;
$count_tot=0;

# - get server name
$SERVER=$ENV{"computername"};

# - try to find the best match of host input parameters

# - 1 - if -hi is used this is the only valid input
if ($input_host ne '')
{
# --- split input parameter $file_list
  @lines_server = split ( /\|/, $input_host );
}
else
{
#  print "No -hi parameter used, checking if we find a directory or file definition\n";
  if ($indir ne '' && $infile ne '')
   {
     $input_servers_def="$indir/$infile";
   }
  if ($indir ne '' && $infile eq '')
   {
     $input_servers_def="$indir/port_check.txt";
   }
  if ($indir eq '' && $infile eq '')
   {
     $input_servers_def="./port_check.txt";
   }
  if ($indir eq '' && $infile ne '')
   {
     $input_servers_def="$infile";
   }

# - input file with server:port definitions
  if (-e $input_servers_def)
   {
     $input_servers=$input_servers_def;
   }  
  else
   {
# - if a specific file is defined and it does not exist, do not switch to other options
    if ($indir ne '' && $infile ne '')
     {
       print "Your defined input file: $indir/$infile cannot be found.\n";
       exit 3;
     } 
    if ($indir ne '')
     {
       $input_servers="$indir/port_check_$SERVER.txt";
     }
    else
     {
       $input_servers="./port_check_$SERVER.txt";
     }
   }
  print "Using input file: $input_servers\n";
} 

# - read server file
&read_server();

if ($dototal eq 'y')
   {
     print "\n";
     print "Total #test: $count_tot ok: $count_ok nok: $count_nok\n";
   }
exit;

# ----
sub read_server
{
if ($input_host eq '')
  {
# --- open server input file
    open (GLOBALS, "$input_servers") or die "step 1: Error: Can't open $input_servers for read: $!";
    @lines_server = <GLOBALS>;
    close GLOBALS or die "step 1: Error: Cannot close $input_servers: $!"; 
  }

# --- loop in servernames
foreach my $lineserver (@lines_server)
  {
    $reqcount++;
# --- first character # = comment?
    $fc = substr($lineserver, 0, 1);
# --- remove blanks
    if ($fc ne '#')
     {
       $lineserver =~ s/^\s+|\s+$//g;
       @rep = split(/\:/ , $lineserver);
       $repcount=@rep;
       $iserver=$rep[0];
       $iport=$rep[1];
       if ($iserver ne '')
        {     
          $count_tot++;
          &check_server();
        }
     }
  }
}

sub check_server
{
#    print "Scanning server: $iserver port: $iport\n";
# - Connect to port number
#    $socket = IO::Socket::INET->new(PeerAddr => $iserver , PeerPort => $iport , Proto => 'tcp' , Timeout => 1);
    $socket = IO::Socket::INET->new(PeerAddr => $iserver , PeerPort => $iport , Proto => $check_protocol , Timeout => 1);
# - Check connection
    if( $socket )
    {
        $count_ok++;
        if ($printopen eq 'y')
         {
            if ($docount ne 'y')
             {
               print "Port $iport/$check_protocol is open from: $SERVER to: $iserver\n" ;
             }
            else
             {
               print "$count_tot Port $iport/$check_protocol is open from: $SERVER to: $iserver\n" ;
             }
         }
    }
    else
    {
        $count_nok++;
        $ip="";
#        if ($packed = gethostbyname($iserver))
#         {
#            $ip = inet_ntoa(inet_aton($packed));
#         }
#        else
#         {
#            $ip="unknown"; 
#         }

        if ($docount ne 'y')
          {
#             print "Port $iport is closed from: $SERVER to: $iserver ip: $ip\n";
             print "Port $iport/$check_protocol is closed from: $SERVER to: $iserver\n";
          }
        else
           {
#             print "==> $count_tot Port $iport is closed from: $SERVER to: $iserver ip: $ip\n";
            print "==> $count_tot Port $iport/$check_protocol is closed from: $SERVER to: $iserver\n";
          }
# - avoid to do a ping multiple times for the same server
        if ($doping eq 'y' && $oldserver ne $iserver)
         {
           $p = Net::Ping->new();
           print "    Server: $iserver is ";
           print "NOT " unless $p->ping($iserver, 2);
           print "reachable with ping\n";
           $p->close();
           $oldserver=$iserver;
         }
    }
}

sub getparams
{
  usage() unless @ARGV gt 0;
  $argCount=$#ARGV + 1;
  for ($i=0 ; $i < $argCount ; $i++) 
  {
	if ($ARGV[$i] =~ /^-\?/)
	{ 
		usage();
	} 

	if ($ARGV[$i] =~ /^-di/ ) 
	{ 
		$indir =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-fi/ )   
	{ 
		$infile =  substr($ARGV[$i],3);
        }   
	if ($ARGV[$i] =~ /^-hi/ ) 
	{ 
		$input_host =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-po/ ) 
	{ 
		$printopen =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-cp/ ) 
	{ 
		$doping =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-pc/ ) 
	{ 
		$docount =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-pt/ ) 
	{ 
		$dototal =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-pr/ ) 
	{ 
		$check_protocol =  substr($ARGV[$i],3);
        }
  }
# - print also open ports ok messages?
if ($printopen eq '') {$printopen="n";}
# - when server port is not open, perform also a ping?
if ($doping eq '') {$doping="n";}
# - print at the end of the tests #ok and #nok
if ($docount eq '') {$docount="n";}
# - print totals as last line
if ($dototal eq '') {$dototal="y";}
if ($check_protocol eq '') {$check_protocol="tcp";}

}

sub usage
 {
   print "      \n";
   print "Port_Check: Check if for a server a port is open from executers host:\n";
   print "      \n";
   print " Input parameters:\n";
   print "  -hi: Host Input, format: \"server:port|server:port\"\n";
   print "  -pr: Protocol, tcp or udp, default: tcp\n";
   print "  -po: Print Open (y/n) default n, print a line for ports that are open\n";
   print "  -cp: Closed Ping (y/n) default n, ping servers where port is closed\n";
   print "  -pc: Print Counter (y/n) default n, add counters in print statements \n";
   print "  -pt: Print Total (y/n) default y, add total ok, nok at the end \n";
   print " Input File (alternative for -hi option):\n";
   print "  -di: input directory (default: c:\\temp)\n";
   print "  -fi: input file (default: port_check.txt or port_check_(servername).txt)\n";
   print "\n";
   exit;
 }
