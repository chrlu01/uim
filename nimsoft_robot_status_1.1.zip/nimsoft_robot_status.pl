#
# This perl will list the robots + probes & the status
#
# 12 February 2018 - Luc Christiaens
#
# based on nimsoft_list_robots.pl
# step1 - gethubs
# step2 - for each returned hub execute: getrobots + list if robot is not active
# step3 - for each returned robot list the not active probes
#
#
# Parameters:
# -d: outout directory (default: c:\temp)
# -f: output file (default: report_nimsoft_robot_status_ok.txt and report_nimsoft_robot_status_nok.txt)
# -h: hub include regex (default: process all hubs)
# -a: generate alarm for hub problems, default: n
# -r: generate alarm for robot problems, default: n
# -p: generate alarm for probe problems, default: n 
# -l: level for generated alarms, default: 1
#
# To do: 
#    test this on big environment if it's quick enough
#    write to an output file
#
# Updates:
# - 15/02/18: add parameter -h: here you can define a hub regex that must be included in the test
# - 28/02/18: add date/time in output
# - 03/03/18: add ip in log file
# - 12/03/18: add subnet overview for connection problems
# - 13/03/18: add also file with robots that work ok
# - 02/05/18: add options -p, -r, -l to generate alarms for the found errors
# - 19/11/20: updated for Perl 5.32
# - 03/08/22: add -a do_alarm_hub, y/n default: n 
# - 04/08/22: nimsoft_generic.dat can be in local directory or in perl/lib
# -         : add a new output file: subnet
# - 08/08/22: changed all options into 2 characters for more logical
#           : add option: -he (hub exclude), -re (robot exclude) and -pe (probe exclude)
# - 13/08/22: add extra output file: hub
#

# --- import
use Nimbus::API;
use Nimbus::Session;
use Nimbus::CFG;
use Nimbus::PDS;
use Getopt::Std;
# crypt
use Crypt::RC4;
use MIME::Base64;
# - crypt key
$crkey="ab_def%hij&5";
# --- to use colors in the print statements
use Win32::Console::ANSI;
use Term::ANSIColor;

# - change directory to directory where perl source is located to find our nimsoft_generic.dat file
use Cwd 'chdir';
use File::Basename;
# --- modif to have nimsoft_generic.pm is same directory as perl source (like a use lib is executed before the real execution we need to use BEGIN)
BEGIN
{
use Cwd;
chdir dirname $0;
$curdir=cwd();
}
use lib "$curdir";
# UIM generic package
use nimsoft_generic;
$pgm="nimsoft_robot_status";
$version="1.1";
$suppression=$pgm;
$host=$ENV{'ComputerName'};

# --- get parameters
&getparams();

# --- show all probes (y) or only inactive probes (n)
$allprobes=$show_probes;

# --- counters
@tab1 = ();
$count_hub=0;
$count_hub_ok=0;
$count_hub_nok=0;
$count_hub_robot_ok=0;
$count_hub_robot_nok=0;
$count_hub_robot_exclude=0;
$count_hub_exclude=0;
$count_robot=0;
$count_robot_ok=0;
$count_robot_nok=0;
$count_robot_exclude=0;
$count_probes=0;
$count_probes_ok=0;
$count_probes_nok=0;
$count_probes_exclude=0;
$count_robot_connection_nok=0;
$count_robot_connection_ok=0;
%cip=();
%cipok=();
%subnet;

# - these are needed for uim requests
$request_timeout = 10;
$request_retries = 1;

# - Open output file for nok
open(OUTCSV, ">$outfil1") || die "Can't open $outfil1: $!\n";

# - Open output file for ok
open(OUTOK, ">$outfil2") || die "Can't open $outfil2: $!\n";

# - Open output file for subnet
open(OUTSUB, ">$outfil3") || die "Can't open $outfil3: $!\n";

# - Open output file for hub
open(OUTHUB, ">$outfil4") || die "Can't open $outfil4: $!\n";

# --- get date time for reports
&calcdate;

# - print date/time as first line in output file
print OUTCSV "Today its $dag $dagnum $maand ($maandnum) $jaar $intim\n";
print OUTCSV "---------------------------------------------------------------\n";

print OUTOK "Today its $dag $dagnum $maand ($maandnum) $jaar $intim\n";
print OUTOK "---------------------------------------------------------------\n";

print OUTSUB "Today its $dag $dagnum $maand ($maandnum) $jaar $intim\n";
print OUTSUB "---------------------------------------------------------------\n";

print OUTHUB "Today its $dag $dagnum $maand ($maandnum) $jaar $intim\n";
print OUTHUB "---------------------------------------------------------------\n";

# --- create uim robot list
&uim_robot_list;
exit;

# --- loop in tab1 to put robot_name and ip in file
$count1 = 1;
$total_tab1=@tab1;
# print "tab1 contains $total_tab1 entries\n";

@sorted_tab1 = sort @tab1;

foreach $objecttab1 (@sorted_tab1)
    {
      @tab1split = split (/\�/, $objecttab1);
      $i_robot="$tab1split[0]";
      $i_ip="$tab1split[1]";
      print OUTCSV "$i_ip $i_robot\n";
      $count1++;
    }

close(OUTCSV);

# ------ Sub Procedures ------

sub uim_robot_list
{
#
# --- Block to read Nimsoft Robots and put them in a table
#

$ihub=0;
$robot_count=0;

# --- Login Nimsoft
my $sid = nimLogin($UIM_username, $UIM_password);

# --- Get Hub address
($rc, $hub_addr) = nimGetVarStr(NIMV_HUBADDR);
if ($rc)
  {
    if ($debug == 2) { print "$prgname rc=$rc from nimGetVarStr NIMV_HUBADDR\n";}
    exit(1);
  }

# --- gethubs
$pds_in = Nimbus::PDS->new();
($rc, $pds_data) = doNimNamedRequest($hub_addr, 'gethubs', $pds_in, $request_timeout, $request_retries);
if ($rc)
  {
     print "rc=$rc of nimNamedRequest 'gethubs' from hub $hub_addr\n";
     $source=$host;
     if ($do_alarm_hub eq 'y') {my ($rc, $id) = nimAlarm($do_alarm_level, "$pgm - rc=$rc of nimNamedRequest: gethubs from hub $hub_addr", "", $suppression, $source);}
  }
$pds_out = Nimbus::PDS->new($pds_data);

# --- Loop in hub list
$ihub = 0;
while(1)
 {
     $hstats="";
     $pds = $pds_out->getTable('hublist', PDS_PDS, $ihub);
     last if (! defined $pds);
     $domain_name = $pds->get('domain', PDS_PCH);
     $hub_addr = $pds->get('addr', PDS_PCH);
     $hub_name = $pds->get('name', PDS_PCH);
     $hub_status = $pds->get('status', PDS_PCH);
     $hub_robot = $pds->get('robotname', PDS_PCH);
#     print "Process hub: $hub_name status: $hub_status\n";
     $count_hub++;
     if ($hub_status eq '0') { $hstat="Active" ; }
     if ($hub_status eq '1') { $hstat="Inactive" ; }
     if ($hub_status eq '2') { $hstat="Inactive" ; }
     if ($hub_status eq '') { $hstat="Inactive" ; }
#     print "hub_name_$count_hub=$hub_name hub_status=$hub_status ($hstat)\n";

# --- Loop in the robots, but only if hub_status = 0
     if ($hub_addr =~ /$hub_exclude/i && $hub_exclude ne '')
        {
          print (color("black on_yellow"),"Exclude hub $count_hub: $hub_name due to regex: $hub_exclude",color("reset"),"\n");
          $ihub++;
          $count_hub_exclude++;
          next;
        } 
            
     if ($hub_status eq '0' && ($hub_addr =~ /$hub_include/i || $hub_include eq 'all'))
       {
         print "Process hub $count_hub: $hub_name\n";
         print OUTCSV "Processing hub $count_hub: $hub_name\n";
         $rch=doRobots($domain_name, $hub_addr, $hub_name); 
         $count_hub_ok++;
       }
     else
       {       
         print (color("black on_yellow"),"Bypass  hub $count_hub: $hub_name hub status: $hub_status ($hstat)",color("reset"),"\n");
         print OUTCSV "Bypass hub $count_hub: $hub_name status: $hub_status ($hstat)\n";
         $count_hub_nok++;
       } 
     print OUTHUB "Hub $count_hub: $hub_name status: $hub_status Robot_ok: $count_hub_robot_ok Robot_nok: $count_hub_robot_nok Robot_excluded: $count_hub_robot_exclude\n";
     $ihub++;
     $count_hub_robot_ok=0;
     $count_hub_robot_nok=0;
     $count_hub_robot_exclude=0;
 }

# --- execute calcdate again to have duration of this script
&calcdate;

print "\n";
print (color("black on_green"),"Processed $ihub hubs and $robot_count robots from online UIM\/Nimsoft (duration: $time_duration)",color("reset"),"\n");
print "   Hub status ok: $count_hub_ok nok: $count_hub_nok excluded: $count_hub_exclude\n";
print "   Robot status ok: $count_robot_ok robot nok: $count_robot_nok excluded: $count_robot_exclude\n";
print "   Robot connection ok: $count_robot_connection_ok nok: $count_robot_connection_nok\n";
print "   Probe ok: $count_probes_ok probe nok: $count_probes_nok excluded: $count_probes_exclude\n";
print "\n";
print (color("black on_green"),"Subnet Overview with robot connection problems:",color("reset"),"\n");
print "\n";
print OUTCSV "\n";
print OUTCSV "Processed $ihub hubs and $robot_count robots from online UIM\/Nimsoft (duration: $time_duration)\n";
print OUTCSV "   Hub status ok: $count_hub_ok nok: $count_hub_nok excluded: $count_hub_exclude\n";
print OUTCSV "   Robot status ok: $count_robot_ok robot nok: $count_robot_nok excluded: $count_robot_exclude\n";
print OUTCSV "   Robot connection ok: $count_robot_connection_ok nok: $count_robot_connection_nok exclude: $count_probes_exclude\n";
print OUTCSV "   Probe ok: $count_probes_ok nok: $count_probes_nok excluded: $count_probes_exclude\n";
print OUTCSV "\n";
print OUTSUB "Subnet Overview with robot connection problems:\n";
print OUTSUB "\n";
foreach $ipentry (sort sortip keys(%cip))
 {
   $over1=$ipentry;
   $over2=$cip{$ipentry};
   print "Subnet: $over1 count: $over2\n";
   print OUTSUB "Subnet: $over1 count: $over2\n";
 }
print "\n";
print (color("black on_green"),"Subnet Overview:",color("reset"),"\n");
print "\n";
print OUTSUB "Subnet Overview:\n";
print OUTSUB "\n";
foreach $name (sort keys %subnet)
 {
   foreach $subject (keys %{ $subnet{$name} } )
    {
       print "$name, $subject: $subnet{$name}{$subject}\n";
       print OUTSUB "$name, $subject: $subnet{$name}{$subject}\n";
    }
 }
print "\n";
print "==== end of report ===\n";

print OUTSUB "\n";
print OUTSUB "==== end of report ===\n";

# --- end with return code # of robots nok
$endrc=$count_robot_nok+$count_robot_connection_nok;
exit $endrc;
#
# --- End of Nimsoft Robot List
#
}

sub doNimNamedRequest
{
    my $address = shift;
    my $command = shift;
    my $data = shift;
    my $timeout = shift;
    my $retries = shift;

    ($rc, $pds_data);
    for (my $itry = 0; $itry < $retries; $itry++)
    {
#        print "nimNamedRequest addr: $address cmd: $command data: $data timeout: $timeout \n";
        ($rc, $pds_data) = nimNamedRequest($address, $command, $data, $timeout);
        last if (! $rc);
        if ($debug == 2) 
         {
           if ($command ne '_status' && $command ne 'list_subscribers' && $command ne 'getrobots' && $command ne 'probe_list')
            {
              print "rc=$rc for nimNamedRequest: address=$address command=$command timeout=$timeout try=$itry\n";
              $source=$host;
              if ($do_alarm_hub eq 'y') {my ($rc, $id) = nimAlarm($do_alarm_level, "$pgm - rc=$rc for nimNamedRequest: address=$address command=$command", "", $suppression, $source);}
            }
         }
    }
    return($rc, $pds_data);
}

sub doRobots
{
    my $domain_name = shift;
    my $hub_addr = shift;
    my $hub_name = shift;
    $robot_status=2;
    $hub_robot_ok=0;
    $hub_robot_nok=0;

#    print "$prgname (doRobots) - domain_name=$domain_name hub_addr=$hub_addr hub_name=$hub_name\n";
    my $pds_in = Nimbus::PDS->new();
    my $pds_data;
    my ($rc, $pds_data) = doNimNamedRequest($hub_addr, 'getrobots', $pds_in, $request_timeout, $request_retries);
    if ($rc)
    {
        print "  rc=$rc from nimNamedRequest 'getrobots' for hub $hub_name ($hub_addr)\n";
        $source=$host;
        if ($do_alarm_hub eq 'y') {my ($rc, $id) = nimAlarm($do_alarm_level, "$pgm - rc=$rc from nimNamedRequest: getrobots for hub $hub_name ($hub_addr)", "", $suppression, $source);}
        return $rc;
    }
    else
    {
      $hbstat=0;
    }

    my $pds_out = Nimbus::PDS->new($pds_data);
    $irobot = 0;
    while(1)
    {
        my $pds = $pds_out->getTable('robotlist', PDS_PDS, $irobot);
        last if (! defined $pds);

        my $robot_addr = $pds->get('addr', PDS_PCH);
        if (! defined $robot_addr)
        {
            print "robotlist returned an empty addr for robot $irobot\n";
            $irobot++;
            next;
        }
        my $robot_name = $pds->get('name', PDS_PCH);
        if (! defined $robot_name)
        {
            print "robotlist returned an empty name for robot at $robot_addr\n";
            $irobot++;
            next;
        }
        $robot_status = $pds->get('status', PDS_INT);
        if (! defined $robot_status)
        {
            print "robotlist returned an empty status for robot at $robot_addr\n";
            $irobot++;
            next;
        }

        if ($robot_addr =~ /$robot_exclude/i && $robot_exclude ne '')
         {
            print (color("black on_yellow"),"Exclude robot: $robot_addr due to regex: $robot_exclude",color("reset"),"\n");
            $irobot++;
            $count_robot_exclude++;
            $count_hub_robot_exclude++;
            next;
         }          

        if ($robot_status == 0) {$active="yes";}
        if ($robot_status == 1) {$active="NO";}
        if ($robot_status == 2) {$active="unknown";}
        if ($robot_status == 4) {$active="maint";}

        $robot_ip = $pds->get('ip', PDS_PCH);

        $irobot++;
        $robot_count++;
        $count_robot++;
        if ($active ne 'yes')
         {
           $count_robot_nok++;
           $count_hub_robot_nok++;
           print "   ** $count_robot_nok robot=$robot_name ip=$robot_ip robot_status=$active\n";
           print OUTCSV "  robot=$robot_name ip=$robot_ip robot_status=$active\n";
           $source=$robot_name;
           if ($do_alarm_robot eq 'y') {my ($rc, $id) = nimAlarm($do_alarm_level, "$pgm - robot=$robot_name ip= $robot_ip robot_status=$active on hub: $hub_name", "", $suppression, $source);}
         } 
        else
         {
            $count_robot_ok++;
            $count_hub_robot_ok++;
#            print "   $count_robot_ok robot=$robot_name robot_status=$active\n";
          } 

# - get probe information
        if ($robot_status eq '0')
          { 
            doProbes($domain_name, $hub_addr, $hub_name, $robot_addr, $robot_name,$robot_ip);
          }

#        print "Add robot $robot_count: $robot_name in install_table for hub: $hub_name ip: $robot_ip status: $active\n";
# --- add robot in table (so we can use exist)
#        if ($hub_robot ne $robot_name)
#          {
#            push(@tab1, "$robot_name\�$robot_ip");
#          }
#        else
#          {
#            print "Exclude hub robot: $hub_robot\n";
#          }
   }

  return $hbstat;
}

sub doProbes
{
    my $domain_name = shift;
    my $hub_addr = shift;
    my $hub_name = shift;
    my $robot_addr = shift;
    my $robot_name = shift;
    my $robot_ip  = shift;

#    nimLog(1, "(doProbes) - domain_name=$domain_name hub_addr=$hub_addr hub_name=$hub_name robot_addr=$robot_addr robot_name=$robot_name");
    my $pds_in = Nimbus::PDS->new();
    my $controller_addr = $robot_addr . '/controller';
    my $pds_data;
    my ($rc, $pds_data) = doNimNamedRequest($controller_addr, 'probe_list', $pds_in->data(), $request_timeout, $request_retries);
    if ($rc)
    {
# --- create counters per subnet
        @ipsplit=split(/\./, $robot_ip);
        $robot_subnet="$ipsplit[0]\.$ipsplit[1]\.$ipsplit[2]";
        $cip{"$robot_subnet"} += 1;
        $subnet{$robot_subnet}{nok} = $cip{"$robot_subnet"};
#        print "  rc=$rc from nimNamedRequest 'probe_list' from controller $controller_addr\n";
        $count_robot_connection_nok++;
        print "  $count_robot_connection_nok Robot: $robot_name ip: $robot_ip hub: $hub_name connection problem subnet: $robot_subnet\n";
        print OUTCSV "  robot: $robot_name ip: $robot_ip hub: $hub_name connection problem subnet: $robot_subnet\n";
        $source=$robot_name;
        if ($do_alarm_robot eq 'y') {my ($rc, $id) = nimAlarm($do_alarm_level, "$pgm - hub=$hub_name robot=$robot_name connection problem", "", $suppression, $source);}
        return;
    }
    else
    {
        $count_robot_connection_ok++;  
        @ipsplit=split(/\./, $robot_ip);
        $robot_subnet="$ipsplit[0]\.$ipsplit[1]\.$ipsplit[2]";
        $cipok{"$robot_subnet"} += 1;
        $subnet{$robot_subnet}{ok} = $cipok{"$robot_subnet"};
        print OUTOK "  $count_robot_connection_ok Robot: $robot_name ip: $robot_ip hub: $hub_name connection ok subnet: $robot_subnet\n";   
    }    
    my $pds_out = Nimbus::PDS->new($pds_data);
# - dump all values
#    $pds_out->dump();
    my $pds_hash = $pds_out->asHash();
#    doPdsHash("/$robot_name", $pds_hash);
    foreach my $probe_name(keys%{($pds_hash)})
    {
        my $value = $pds_hash->{$probe_name};
        my $ref = ref($value);
        if ($ref eq 'HASH')
        {
            doPdsHash($pds_path . $key, $value) if ($ref eq 'HASH');
        }
        else
        {
#             print "doPdsHash2: robot: $robot_name probe: $probe_name $pds_path $key=$value\n";

        }
#        print "hub_name=$hub_name robot_name=$robot_name robot_status=$active probe_name=$probe_name probe_status=$probe_active\n";
         $trans="";
         if ($probe_active ne '1') 
            {
               $count_probes_nok++; 
               if ($probe_active eq '0')
                {
                   $trans="Inactive"; 
                }
               else
                {
                   $trans="unknown"; 
                }
            }
         if ($probe_active eq '1') 
            { 
              $trans="Active"; 
              $count_probes_ok++;
            }
# - do we have a probe exclude?
        $probe_addr="/$hub_name/$robot_name/$probe_name";  
        if ($probe_addr =~ /$probe_exclude/i && $probe_exclude ne '')
         {
            print (color("black on_yellow"),"Exclude probe: $probe_addr due to regex: $probe_exclude",color("reset"),"\n");
            $count_probes_exclude++;
         }
        else
         {
          if ($allprobes eq 'n' && $probe_active ne '1')
           {
             print "      robot=$robot_name probe_name=$probe_name probe_status=$probe_active ($trans)\n";
             print OUTCSV "    robot=$robot_name probe_name=$probe_name probe_status=$probe_active ($trans)  \n";
             $source=$robot_name;
             if ($do_alarm_probe eq 'y') {my ($rc, $id) = nimAlarm($do_alarm_level, "$pgm - hub=$hub_name robot=$robot_name probe=$probe_name probe_status=$probe_active ($trans)", "", $suppression, $source);}
           }
          else
           {
             if ($allprobes eq 'y')
               {
                  print OUTCSV "    robot=$robot_name probe_name=$probe_name probe_status=$probe_active ($trans)  \n";
                  $source=$robot_name;
               }
           }
        }
    }
}

sub doPdsHash
{
    my $pds_path = shift;
    my $pds_hash = shift;

    foreach my $key(keys%{($pds_hash)})
    {
        my $value = $pds_hash->{$key};
        my $ref = ref($value);
        if ($ref eq 'HASH')
        {
            doPdsHash($pds_path . $key, $value) if ($ref eq 'HASH');
        }
        else
        {
#             print "doPdsHash1: $pds_path $key=$value\n";
             if ($key eq 'active')
              {
                $probe_active=$value;
              }
        }
    }
}

sub sortip
{
  $cip{$a} <=> $cip{$b};
}


sub calcdate
 {
  $timeval = time();
  @timelist = gmtime ($timeval);
  if (@timelist[6] eq '0') { $dag = "Sunday" }
  if (@timelist[6] eq '1') { $dag = "Monday" }
  if (@timelist[6] eq '2') { $dag = "Tuesday" }
  if (@timelist[6] eq '3') { $dag = "Wednesday" }
  if (@timelist[6] eq '4') { $dag = "Thursday" }
  if (@timelist[6] eq '5') { $dag = "Friday" }
  if (@timelist[6] eq '6') { $dag = "Saturday" }
  if (@timelist[4] eq '0') { $maand = "January" }
  if (@timelist[4] eq '1') { $maand = "February" }
  if (@timelist[4] eq '2') { $maand = "March" }
  if (@timelist[4] eq '3') { $maand = "April" }
  if (@timelist[4] eq '4') { $maand = "May" }
  if (@timelist[4] eq '5') { $maand = "June" }
  if (@timelist[4] eq '6') { $maand = "July" }
  if (@timelist[4] eq '7') { $maand = "Augustus" }
  if (@timelist[4] eq '8') { $maand = "September" }
  if (@timelist[4] eq '9') { $maand = "October" }
  if (@timelist[4] eq '10') { $maand = "November" }
  if (@timelist[4] eq '11') { $maand = "December" }
  $maandnum = @timelist[4] +1;
  $dagnum = @timelist[3] ;
  $jaar = @timelist[5] + 1900;
#
# get time 
#
  $intim1 = time();
  $intim2 = localtime($intim1);
  @intime = split(/ +/ , $intim2);
  $intim = $intime[3]; 

#
# start and end time
#
 if ($start_time ne '')
  {
    $end_time=time();
    $diff_time=$end_time-$start_time;
    $diff_time_min=int($diff_time/60);
    $diff_time_sec=int($diff_time%60);
    $time_duration="$diff_time_min:$diff_time_sec (mm:ss)";
    print "\n";
    print "Starttime: $start_time Endtime: $end_time Difference: $diff_time Duration: $time_duration\n";
  }
 if ($start_time eq '')
  {
    $start_time=time();
  }

  print "\n"; 
  print ("Today its $dag $dagnum $maand ($maandnum) $jaar $intim \n");
  print "\n";
 }

sub getparams
{
  usage() unless @ARGV gt 0;
  $argCount=$#ARGV + 1;
  for ($i=0 ; $i < $argCount ; $i++) 
  {
	if ($ARGV[$i] =~ /^-\?/)
	{ 
		usage();
	} 
   
	if ($ARGV[$i] =~ /^-fd/ ) 
	{ 
		$outdir =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-fn/ ) 
	{ 
		$outfile =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-ah/ ) 
	{ 
		$do_alarm_hub =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-ar/ ) 
	{ 
		$do_alarm_robot =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-ap/ ) 
	{ 
		$do_alarm_probe =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-al/ ) 
	{ 
		$do_alarm_level =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-rp/ ) 
	{ 
		$show_probes =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-hi/ ) 
	{ 
		$hub_include =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-he/ ) 
	{ 
		$hub_exclude =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-re/ ) 
	{ 
		$robot_exclude =  substr($ARGV[$i],3);
        }
	if ($ARGV[$i] =~ /^-pe/ ) 
	{ 
		$probe_exclude =  substr($ARGV[$i],3);
        }
   }






# --- get credentials and settings from common file (nimsoft_generic.dat)
($Server_With_Rest_Interface, $RestServicePort, $UIM_username, $UIM_password,$UIM_Domain,$UIM_Hub,$UIM_Robot,$sql_server,$sql_user,$sql_password,$sql_db) = nimsoft_generic::getRestData();

# -- de-crypt (need $encoded)
$decoded = decode_base64($UIM_password);
$UIM_password = RC4($crkey, $decoded);

$decoded = decode_base64($sql_password);
$sql_password = RC4($crkey, $decoded);

# --- if not used in parameters, use defaults from generic
if ($sqluser eq '') { $sqluser=$sql_user; }
if ($sqlpass eq '') { $sqlpass=$sql_password; }
if ($sqlserver eq '') { $sqlserver=$sql_server; }
if ($database eq '') { $database=$sql_db; }

  if ($outdir eq '')
   {
     $outdir = "c:\\temp";
   }

  if ($outfile eq '')
   {
     $outfile1 = "report\_nimsoft\_robot\_status\_nok.txt";
     $outfile2 = "report\_nimsoft\_robot\_status\_ok.txt";
     $outfile3 = "report\_nimsoft\_robot\_status\_subnet.txt";
     $outfile4 = "report\_nimsoft\_robot\_status\_hub.txt";
   }
  if ($do_alarm_robot eq '')
   {
     $do_alarm_robot = "n";
   }
  if ($do_alarm_probe eq '')
   {
     $do_alarm_probe = "n";
   }
  if ($do_alarm_level eq '')
   {
     $do_alarm_level = "1";
   }
  if ($do_alarm eq '')
   {
     $do_alarm = "n";
   }
  if ($show_probes eq '')
   {
     $show_probes = "n";
   }

# --- create dir + name
  $outfil1 = "$outdir\\$outfile1";
  $outfil2 = "$outdir\\$outfile2";
  $outfil3 = "$outdir\\$outfile3";
  $outfil4 = "$outdir\\$outfile4";
}

sub usage
 {
   print "      \n";
   print (color("black on_green"),"nimsoft_robot_status.pl (version: $version)",color("reset"),"\n");
   print "      \n";
   print "  -fd: (opt), output file directory, default: c:\\temp\n";
   print "  -fn: (opt), output file name start, default: report_nimsoft_robot_status\n";
   print "\n";
   print (color("black on_yellow"),"   (include/exclude tests are in UIM address format, with a / escaped as \\/)",color("reset"),"\n");
   print "  -hi: (opt), regex hubs to include, use: \"all\" to check all hubs\n";
   print "\n";
   print "  -he: (opt), regex hub exclude\n";
   print "  -re: (opt), regex robot exclude\n";
   print "  -pe: (opt), regex probe exclude\n";
   print "\n";
   print "  -ah: (opt), generate alarm for hub problems (default: n)\n";
   print "  -ar: (opt), generate alarm for robot problems (default: n)\n";
   print "  -ap: (opt), generate alarm for probe problems (default: n)\n";
   print "  -al: (opt), alarm level (1-5), default: 1\n";
   print "\n";
   print "  -rp: (opt), report all probes (y) or only inactive probes (n), default: n\n";
   print "\n";
   exit 0;
 }


